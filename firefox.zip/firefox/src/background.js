firefox.runtime.onInstalled.addListener(() => {
  console.log("NotionFarsi-RTL Extension Installed");
});
